package com.example.headhunter

import android.os.Parcel
import android.os.Parcelable

data class Job(
    val title: String,
    val companyName: String,
    val location: String,
    val experience: String,
    val description: String,
    val postedDate: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(title)
        parcel.writeString(companyName)
        parcel.writeString(location)
        parcel.writeString(experience)
        parcel.writeString(description)
        parcel.writeString(postedDate)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Job> {
        override fun createFromParcel(parcel: Parcel): Job {
            return Job(parcel)
        }

        override fun newArray(size: Int): Array<Job?> {
            return arrayOfNulls(size)
        }
    }
}