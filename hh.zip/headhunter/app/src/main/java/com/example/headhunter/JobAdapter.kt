package com.example.headhunter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.headhunter.databinding.ItemJobBinding

class JobAdapter(
    private var jobs: List<Job>,
    private val onJobClick: (Job) -> Unit
) : RecyclerView.Adapter<JobAdapter.JobViewHolder>() {

    inner class JobViewHolder(private val binding: ItemJobBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(job: Job) {
            binding.jobTitle.text = job.title
            binding.companyName.text = job.companyName
            binding.jobLocation.text = job.location
            binding.experience.text = job.experience
            binding.postedDate.text = job.postedDate

            // При нажатии на вакансию передаем данные в onJobClick
            binding.applyButton.setOnClickListener {
                onJobClick(job)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val binding = ItemJobBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bind(jobs[position])
    }

    override fun getItemCount(): Int = jobs.size

    fun updateList(newJobs: List<Job>) {
        jobs = newJobs
        notifyDataSetChanged()
    }
}