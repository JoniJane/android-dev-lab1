package com.example.headhunter

import com.google.android.material.badge.BadgeDrawable
import com.google.android.material.bottomnavigation.BottomNavigationView

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.headhunter.Job
import com.example.headhunter.JobAdapter
import com.example.headhunter.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var jobAdapter: JobAdapter
    private var jobList = listOf(
        Job(
            title = "Android Developer (Kotlin)",
            companyName = "АО «OTP Банк» (JSC «OTP Bank»)",
            location = "Москва",
            description = "Android Developer(Kotlin)",
            experience = "Опыт от 3 до 6 лет",
            postedDate = "Опубликовано 3 октября"
        ),
        Job(
            title = "Android Разработчик (Middle/Senior)",
            companyName = "RedLab",
            location = "Тбилиси",
            description = "Android Разработчик (Middle/Senior)",
            experience = "Опыт от 3 до 6 лет",
            postedDate = "Опубликовано 3 октября"
        )
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        jobAdapter = JobAdapter(jobList) { selectedJob ->
            // Переход на экран деталей вакансии
            val intent = Intent(this, VacancyDetailsActivity::class.java).apply {
                putExtra("JOB_DETAILS", selectedJob)
            }
            startActivity(intent)
        }

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = jobAdapter
        }

        // Set up Bottom Navigation View
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_search -> {
                    // Handle Search navigation
                    true
                }

                R.id.nav_favorites -> {
                    // Handle Favorites navigation
                    true
                }

                R.id.nav_responses -> {
                    // Handle Responses navigation
                    true
                }

                R.id.nav_messages -> {
                    // Handle Messages navigation
                    true
                }

                R.id.nav_profile -> {
                    // Handle Profile navigation
                    true
                }

                else -> false
            }
        }

        // Реализуем поиск вакансий по ключевым словам
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterJobs(s.toString())
            }
        })
    }

    private fun filterJobs(query: String) {
        val filteredList = jobList.filter {
            it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
        }
        jobAdapter.updateList(filteredList)
    }
}