package com.example.headhunter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.headhunter.databinding.ActivityVacancyDetailsBinding

class VacancyDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityVacancyDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVacancyDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Получаем данные о вакансии, переданные из MainActivity
        val job = intent.getParcelableExtra<Job>("JOB_DETAILS")

        // Устанавливаем данные о вакансии в UI
        job?.let {
            binding.vacancyTitle.text = it.title
            binding.vacancyExperience.text = getString(R.string.experience_format, it.experience)
            binding.vacancyDescription.text = getString(R.string.text)
            binding.vacancySalary.text = "Уровень дохода не указан"
            binding.vacancyEmployment.text = "Полная занятость, удаленная работа"
        }
    }
}